# 📋 Gerenciador de Tarefas

Um gerenciador de tarefas completo desenvolvido com Django, SQLite e interface moderna em HTML/CSS/JavaScript.

## 🚀 Funcionalidades

- ✅ **CRUD Completo**: Criar, Ler, Atualizar e Deletar tarefas
- 📊 **Status de Tarefas**: Pendente, Em Andamento, Concluída
- 🎯 **Prioridades**: Baixa, Média, Alta
- 🔍 **Filtros**: Por status e prioridade
- 📱 **Interface Responsiva**: Funciona em desktop e mobile
- 🎨 **Design Moderno**: Interface bonita e intuitiva
- ⚡ **API REST**: Backend robusto com Django REST Framework
- 🗄️ **Banco SQLite**: Simples e eficiente
- 🧪 **Testes Automatizados**: Cobertura de todas as operações da API

## 🛠️ Tecnologias Utilizadas

### Backend
- **Django 4.2.7**: Framework web Python
- **Django REST Framework**: API REST
- **SQLite**: Banco de dados
- **Django CORS Headers**: Suporte a CORS

### Frontend
- **HTML5**: Estrutura semântica
- **CSS3**: Design moderno com gradientes e animações
- **JavaScript ES6+**: Funcionalidades interativas
- **Font Awesome**: Ícones

## 📦 Instalação

### Pré-requisitos
- Python 3.8 ou superior
- pip (gerenciador de pacotes Python)

### Passos para instalação

1. **Clone ou baixe o projeto**
   ```bash
   git clone <url-do-repositorio>
   cd gerenciador
   ```

2. **Instale as dependências**
   ```bash
   pip install -r requirements.txt
   ```

3. **Execute as migrações do banco de dados**
   ```bash
   python manage.py makemigrations
   python manage.py migrate
   ```

4. **Crie um superusuário (opcional)**
   ```bash
   python manage.py createsuperuser
   ```

5. **Inicie o servidor**
   ```bash
   python manage.py runserver
   ```

6. **Acesse a aplicação**
   - Frontend: http://localhost:8000
   - Admin Django: http://localhost:8000/admin

## 🧪 Testes Automatizados

O projeto possui testes unitários automatizados para o backend (Django REST Framework), cobrindo todas as operações principais da API de tarefas:

- Listar tarefas
- Criar tarefa
- Detalhar tarefa
- Atualizar tarefa
- Deletar tarefa
- Alterar status
- Filtrar tarefas por status e prioridade

### Como rodar os testes

Execute o comando abaixo na raiz do projeto:

```bash
python manage.py test tarefas
```

Você verá o resultado dos testes no terminal. Todos os testes devem passar se o sistema estiver funcionando corretamente.

## 🎯 Como Usar

### Interface Principal
1. **Criar Tarefa**: Preencha o formulário no topo da página
2. **Visualizar Tarefas**: Todas as tarefas aparecem na lista
3. **Editar Tarefa**: Clique no botão "Editar" de qualquer tarefa
4. **Deletar Tarefa**: Clique no botão "Deletar" (com confirmação)
5. **Alterar Status**: Use os botões "Concluir", "Iniciar" ou "Pausar"

### Filtros
- **Por Status**: Pendente, Em Andamento, Concluída
- **Por Prioridade**: Baixa, Média, Alta
- **Limpar Filtros**: Remove todos os filtros aplicados

### Funcionalidades Avançadas
- **Modal de Edição**: Interface intuitiva para editar tarefas
- **Notificações Toast**: Feedback visual para todas as ações
- **Responsividade**: Funciona perfeitamente em dispositivos móveis
- **Animações**: Transições suaves e efeitos visuais

## 📁 Estrutura do Projeto

```
gerenciador/
├── gerenciador_tarefas/     # Configurações do projeto Django
│   ├── __init__.py
│   ├── settings.py          # Configurações do Django
│   ├── urls.py              # URLs principais
│   ├── wsgi.py              # Configuração WSGI
│   └── asgi.py              # Configuração ASGI
├── tarefas/                 # Aplicação de tarefas
│   ├── __init__.py
│   ├── models.py            # Modelo Tarefa
│   ├── views.py             # Views da API
│   ├── serializers.py       # Serializers para API
│   ├── urls.py              # URLs da aplicação
│   ├── admin.py             # Configuração do admin
│   └── tests.py             # Testes automatizados
├── templates/               # Templates HTML
│   └── index.html           # Template principal
├── static/                  # Arquivos estáticos
│   ├── css/
│   │   └── style.css        # Estilos CSS
│   └── js/
│       └── app.js           # JavaScript da aplicação
├── manage.py                # Script de gerenciamento Django
├── requirements.txt         # Dependências Python
└── README.md               # Este arquivo
```

## 🔧 API Endpoints

### Tarefas
- `GET /api/tarefas/` - Listar todas as tarefas
- `POST /api/tarefas/criar/` - Criar nova tarefa
- `GET /api/tarefas/{id}/` - Detalhes de uma tarefa
- `PUT /api/tarefas/{id}/atualizar/` - Atualizar tarefa
- `DELETE /api/tarefas/{id}/deletar/` - Deletar tarefa
- `PATCH /api/tarefas/{id}/status/` - Alterar status
- `GET /api/tarefas/filtrar/` - Filtrar tarefas

### Exemplo de uso da API

```javascript
// Criar tarefa
const novaTarefa = {
    titulo: "Minha tarefa",
    descricao: "Descrição da tarefa",
    prioridade: "media"
};

fetch('/api/tarefas/criar/', {
    method: 'POST',
    headers: {
        'Content-Type': 'application/json',
    },
    body: JSON.stringify(novaTarefa)
});
```

## 🎨 Personalização

### Cores e Estilo
O design pode ser personalizado editando o arquivo `static/css/style.css`:

```css
/* Cores principais */
:root {
    --primary-color: #667eea;
    --secondary-color: #764ba2;
    --success-color: #28a745;
    --warning-color: #ffc107;
    --danger-color: #dc3545;
}
```

### Funcionalidades
Novas funcionalidades podem ser adicionadas editando:
- `tarefas/models.py` - Novos campos no modelo
- `tarefas/views.py` - Novas funcionalidades da API
- `static/js/app.js` - Novas funcionalidades do frontend

## 🚀 Deploy

### Desenvolvimento
```bash
python manage.py runserver
```

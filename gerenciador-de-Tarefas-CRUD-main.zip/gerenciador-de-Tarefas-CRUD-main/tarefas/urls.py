from django.urls import path
from . import views

urlpatterns = [
    # Rotas principais
    path('tarefas/', views.listar_tarefas, name='listar_tarefas'),
    path('tarefas/criar/', views.criar_tarefa, name='criar_tarefa'),
    path('tarefas/filtrar/', views.filtrar_tarefas, name='filtrar_tarefas'),
    
    # Rotas para tarefas específicas
    path('tarefas/<int:tarefa_id>/', views.detalhar_tarefa, name='detalhar_tarefa'),
    path('tarefas/<int:tarefa_id>/atualizar/', views.atualizar_tarefa, name='atualizar_tarefa'),
    path('tarefas/<int:tarefa_id>/deletar/', views.deletar_tarefa, name='deletar_tarefa'),
    path('tarefas/<int:tarefa_id>/status/', views.alterar_status, name='alterar_status'),
] 
from django.db import models
from django.utils import timezone

class Tarefa(models.Model):
    """Modelo para representar uma tarefa"""
    
    STATUS_CHOICES = [
        ('pendente', 'Pendente'),
        ('em_andamento', 'Em Andamento'),
        ('concluida', 'Concluída'),
    ]
    
    PRIORIDADE_CHOICES = [
        ('baixa', 'Baixa'),
        ('media', 'Média'),
        ('alta', 'Alta'),
    ]
    
    titulo = models.CharField(max_length=200, verbose_name='Título')
    descricao = models.TextField(blank=True, null=True, verbose_name='Descrição')
    status = models.CharField(
        max_length=20, 
        choices=STATUS_CHOICES, 
        default='pendente',
        verbose_name='Status'
    )
    prioridade = models.CharField(
        max_length=20, 
        choices=PRIORIDADE_CHOICES, 
        default='media',
        verbose_name='Prioridade'
    )
    data_criacao = models.DateTimeField(
        auto_now_add=True, 
        verbose_name='Data de Criação'
    )
    data_conclusao = models.DateTimeField(
        blank=True, 
        null=True, 
        verbose_name='Data de Conclusão'
    )
    
    class Meta:
        verbose_name = 'Tarefa'
        verbose_name_plural = 'Tarefas'
        ordering = ['-data_criacao']
    
    def __str__(self):
        return self.titulo
    
    def save(self, *args, **kwargs):
        # Se o status foi alterado para 'concluida', definir data de conclusão
        if self.status == 'concluida' and not self.data_conclusao:
            self.data_conclusao = timezone.now()
        elif self.status != 'concluida':
            self.data_conclusao = None
        super().save(*args, **kwargs) 
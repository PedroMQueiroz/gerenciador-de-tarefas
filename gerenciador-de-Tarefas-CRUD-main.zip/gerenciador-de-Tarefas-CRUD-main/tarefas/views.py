from rest_framework import status
from rest_framework.decorators import api_view
from rest_framework.response import Response
from django.shortcuts import get_object_or_404
from .models import Tarefa
from .serializers import TarefaSerializer, TarefaCreateSerializer, TarefaUpdateSerializer

@api_view(['GET'])
def listar_tarefas(request):
    """Lista todas as tarefas"""
    try:
        tarefas = Tarefa.objects.all()
        serializer = TarefaSerializer(tarefas, many=True)
        return Response({
            'tarefas': serializer.data,
            'sucesso': True,
            'total': tarefas.count()
        })
    except Exception as e:
        return Response({
            'erro': str(e),
            'sucesso': False
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['POST'])
def criar_tarefa(request):
    """Cria uma nova tarefa"""
    try:
        serializer = TarefaCreateSerializer(data=request.data)
        if serializer.is_valid():
            tarefa = serializer.save()
            tarefa_serializer = TarefaSerializer(tarefa)
            return Response({
                'mensagem': 'Tarefa criada com sucesso!',
                'tarefa': tarefa_serializer.data,
                'sucesso': True
            }, status=status.HTTP_201_CREATED)
        else:
            return Response({
                'erro': serializer.errors,
                'sucesso': False
            }, status=status.HTTP_400_BAD_REQUEST)
    except Exception as e:
        return Response({
            'erro': str(e),
            'sucesso': False
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['GET'])
def detalhar_tarefa(request, tarefa_id):
    """Retorna detalhes de uma tarefa específica"""
    try:
        tarefa = get_object_or_404(Tarefa, id=tarefa_id)
        serializer = TarefaSerializer(tarefa)
        return Response({
            'tarefa': serializer.data,
            'sucesso': True
        })
    except Exception as e:
        return Response({
            'erro': str(e),
            'sucesso': False
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['PUT'])
def atualizar_tarefa(request, tarefa_id):
    """Atualiza uma tarefa existente"""
    try:
        tarefa = get_object_or_404(Tarefa, id=tarefa_id)
        serializer = TarefaUpdateSerializer(tarefa, data=request.data)
        if serializer.is_valid():
            tarefa = serializer.save()
            tarefa_serializer = TarefaSerializer(tarefa)
            return Response({
                'mensagem': 'Tarefa atualizada com sucesso!',
                'tarefa': tarefa_serializer.data,
                'sucesso': True
            })
        else:
            return Response({
                'erro': serializer.errors,
                'sucesso': False
            }, status=status.HTTP_400_BAD_REQUEST)
    except Exception as e:
        return Response({
            'erro': str(e),
            'sucesso': False
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['DELETE'])
def deletar_tarefa(request, tarefa_id):
    """Deleta uma tarefa"""
    try:
        tarefa = get_object_or_404(Tarefa, id=tarefa_id)
        tarefa.delete()
        return Response({
            'mensagem': 'Tarefa deletada com sucesso!',
            'sucesso': True
        })
    except Exception as e:
        return Response({
            'erro': str(e),
            'sucesso': False
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['PATCH'])
def alterar_status(request, tarefa_id):
    """Altera apenas o status de uma tarefa"""
    try:
        tarefa = get_object_or_404(Tarefa, id=tarefa_id)
        novo_status = request.data.get('status')
        
        if novo_status not in ['pendente', 'em_andamento', 'concluida']:
            return Response({
                'erro': 'Status inválido. Use: pendente, em_andamento ou concluida',
                'sucesso': False
            }, status=status.HTTP_400_BAD_REQUEST)
        
        tarefa.status = novo_status
        tarefa.save()
        
        serializer = TarefaSerializer(tarefa)
        return Response({
            'mensagem': 'Status alterado com sucesso!',
            'tarefa': serializer.data,
            'sucesso': True
        })
    except Exception as e:
        return Response({
            'erro': str(e),
            'sucesso': False
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR)

@api_view(['GET'])
def filtrar_tarefas(request):
    """Filtra tarefas por status e/ou prioridade"""
    try:
        status_filter = request.GET.get('status')
        prioridade_filter = request.GET.get('prioridade')
        
        tarefas = Tarefa.objects.all()
        
        if status_filter:
            tarefas = tarefas.filter(status=status_filter)
        
        if prioridade_filter:
            tarefas = tarefas.filter(prioridade=prioridade_filter)
        
        serializer = TarefaSerializer(tarefas, many=True)
        return Response({
            'tarefas': serializer.data,
            'sucesso': True,
            'total': tarefas.count()
        })
    except Exception as e:
        return Response({
            'erro': str(e),
            'sucesso': False
        }, status=status.HTTP_500_INTERNAL_SERVER_ERROR) 
from rest_framework import serializers
from .models import Tarefa
from django.utils import timezone
import pytz

class TarefaSerializer(serializers.ModelSerializer):
    """Serializer para o modelo Tarefa"""
    
    class Meta:
        model = Tarefa
        fields = '__all__'
        read_only_fields = ('data_criacao', 'data_conclusao')
    
    def to_representation(self, instance):
        """Personaliza a representação dos dados"""
        representation = super().to_representation(instance)
        
        # Converter para timezone de São Paulo antes de formatar
        tz_sp = pytz.timezone('America/Sao_Paulo')
        
        # Formatar datas para melhor visualização
        if instance.data_criacao:
            # Converter para timezone local se a data tem timezone
            if timezone.is_aware(instance.data_criacao):
                data_local = instance.data_criacao.astimezone(tz_sp)
            else:
                data_local = timezone.make_aware(instance.data_criacao, tz_sp)
            representation['data_criacao'] = data_local.strftime('%d/%m/%Y %H:%M')
        
        if instance.data_conclusao:
            # Converter para timezone local se a data tem timezone
            if timezone.is_aware(instance.data_conclusao):
                data_local = instance.data_conclusao.astimezone(tz_sp)
            else:
                data_local = timezone.make_aware(instance.data_conclusao, tz_sp)
            representation['data_conclusao'] = data_local.strftime('%d/%m/%Y %H:%M')
        
        return representation

class TarefaCreateSerializer(serializers.ModelSerializer):
    """Serializer para criação de tarefas"""
    
    class Meta:
        model = Tarefa
        fields = ['titulo', 'descricao', 'prioridade']
    
    def validate_titulo(self, value):
        """Validação personalizada para o título"""
        if len(value.strip()) < 3:
            raise serializers.ValidationError("O título deve ter pelo menos 3 caracteres.")
        return value.strip()

class TarefaUpdateSerializer(serializers.ModelSerializer):
    """Serializer para atualização de tarefas"""
    
    class Meta:
        model = Tarefa
        fields = ['titulo', 'descricao', 'status', 'prioridade']
    
    def validate_titulo(self, value):
        """Validação personalizada para o título"""
        if len(value.strip()) < 3:
            raise serializers.ValidationError("O título deve ter pelo menos 3 caracteres.")
        return value.strip() 
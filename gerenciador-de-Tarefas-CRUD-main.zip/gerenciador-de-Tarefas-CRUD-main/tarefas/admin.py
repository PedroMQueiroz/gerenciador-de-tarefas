from django.contrib import admin
from .models import Tarefa

@admin.register(Tarefa)
class TarefaAdmin(admin.ModelAdmin):
    """Configuração do admin para o modelo Tarefa"""
    
    list_display = ('titulo', 'status', 'prioridade', 'data_criacao', 'data_conclusao')
    list_filter = ('status', 'prioridade', 'data_criacao')
    search_fields = ('titulo', 'descricao')
    readonly_fields = ('data_criacao', 'data_conclusao')
    
    fieldsets = (
        ('Informações Básicas', {
            'fields': ('titulo', 'descricao')
        }),
        ('Status e Prioridade', {
            'fields': ('status', 'prioridade')
        }),
        ('Datas', {
            'fields': ('data_criacao', 'data_conclusao'),
            'classes': ('collapse',)
        }),
    )
    
    def get_queryset(self, request):
        """Ordena as tarefas por data de criação (mais recentes primeiro)"""
        return super().get_queryset(request).order_by('-data_criacao') 
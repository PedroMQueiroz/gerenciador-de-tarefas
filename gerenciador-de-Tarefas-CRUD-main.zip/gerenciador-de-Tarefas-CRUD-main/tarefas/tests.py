from django.urls import reverse
from rest_framework import status
from rest_framework.test import APITestCase
from .models import Tarefa

class TarefaAPITests(APITestCase):
    def setUp(self):
        self.tarefa1 = Tarefa.objects.create(
            titulo='Tarefa 1',
            descricao='Descrição da tarefa 1',
            prioridade='media',
            status='pendente'
        )
        self.tarefa2 = Tarefa.objects.create(
            titulo='Tarefa 2',
            descricao='Descrição da tarefa 2',
            prioridade='alta',
            status='em_andamento'
        )

    def test_listar_tarefas(self):
        url = reverse('listar_tarefas')
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('tarefas', response.data)
        self.assertEqual(len(response.data['tarefas']), 2)

    def test_criar_tarefa(self):
        url = reverse('criar_tarefa')
        dados = {
            'titulo': 'Nova tarefa',
            'descricao': 'Descrição nova',
            'prioridade': 'baixa'
        }
        response = self.client.post(url, dados, format='json')
        self.assertEqual(response.status_code, status.HTTP_201_CREATED)
        self.assertTrue(response.data['sucesso'])
        self.assertEqual(Tarefa.objects.count(), 3)

    def test_detalhar_tarefa(self):
        url = reverse('detalhar_tarefa', args=[self.tarefa1.id])
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertIn('tarefa', response.data)
        self.assertEqual(response.data['tarefa']['titulo'], 'Tarefa 1')

    def test_atualizar_tarefa(self):
        url = reverse('atualizar_tarefa', args=[self.tarefa1.id])
        dados = {
            'titulo': 'Tarefa 1 Editada',
            'descricao': 'Nova descrição',
            'status': 'em_andamento',
            'prioridade': 'alta'
        }
        response = self.client.put(url, dados, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.tarefa1.refresh_from_db()
        self.assertEqual(self.tarefa1.titulo, 'Tarefa 1 Editada')
        self.assertEqual(self.tarefa1.status, 'em_andamento')

    def test_deletar_tarefa(self):
        url = reverse('deletar_tarefa', args=[self.tarefa1.id])
        response = self.client.delete(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertFalse(Tarefa.objects.filter(id=self.tarefa1.id).exists())

    def test_alterar_status(self):
        url = reverse('alterar_status', args=[self.tarefa2.id])
        dados = {'status': 'concluida'}
        response = self.client.patch(url, dados, format='json')
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.tarefa2.refresh_from_db()
        self.assertEqual(self.tarefa2.status, 'concluida')
        self.assertIsNotNone(self.tarefa2.data_conclusao)

    def test_filtrar_tarefas_por_status(self):
        url = reverse('filtrar_tarefas') + '?status=pendente'
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['tarefas']), 1)
        self.assertEqual(response.data['tarefas'][0]['titulo'], 'Tarefa 1')

    def test_filtrar_tarefas_por_prioridade(self):
        url = reverse('filtrar_tarefas') + '?prioridade=alta'
        response = self.client.get(url)
        self.assertEqual(response.status_code, status.HTTP_200_OK)
        self.assertEqual(len(response.data['tarefas']), 1)
        self.assertEqual(response.data['tarefas'][0]['titulo'], 'Tarefa 2') 
// Configurações da API
const API_BASE_URL = '/api';

// Elementos do DOM
const formNovaTarefa = document.getElementById('formNovaTarefa');
const formEditarTarefa = document.getElementById('formEditarTarefa');
const listaTarefas = document.getElementById('listaTarefas');
const loading = document.getElementById('loading');
const semTarefas = document.getElementById('semTarefas');
const totalTarefas = document.getElementById('totalTarefas');
const modalEditar = document.getElementById('modalEditar');
const toast = document.getElementById('toast');
const toastMessage = document.getElementById('toastMessage');
const toastIcon = document.getElementById('toastIcon');

// Filtros
const filtroStatus = document.getElementById('filtroStatus');
const filtroPrioridade = document.getElementById('filtroPrioridade');
const btnLimparFiltros = document.getElementById('btnLimparFiltros');

// Estado da aplicação
let tarefas = [];
let tarefaEditando = null;

// Inicialização
document.addEventListener('DOMContentLoaded', function() {
    carregarTarefas();
    setupEventListeners();
});

// Configuração dos event listeners
function setupEventListeners() {
    // Formulário de nova tarefa
    formNovaTarefa.addEventListener('submit', criarTarefa);
    
    // Formulário de edição
    formEditarTarefa.addEventListener('submit', atualizarTarefa);
    
    // Filtros
    filtroStatus.addEventListener('change', aplicarFiltros);
    filtroPrioridade.addEventListener('change', aplicarFiltros);
    btnLimparFiltros.addEventListener('click', limparFiltros);
}

// Funções da API
async function carregarTarefas() {
    try {
        mostrarLoading(true);
        const response = await fetch(`${API_BASE_URL}/tarefas/`);
        const data = await response.json();
        
        if (data.sucesso) {
            tarefas = data.tarefas;
            renderizarTarefas(tarefas);
            atualizarContador(tarefas.length);
        } else {
            mostrarToast('Erro ao carregar tarefas', 'error');
        }
    } catch (error) {
        console.error('Erro ao carregar tarefas:', error);
        mostrarToast('Erro ao carregar tarefas', 'error');
    } finally {
        mostrarLoading(false);
    }
}

async function criarTarefa(event) {
    event.preventDefault();
    
    const formData = new FormData(formNovaTarefa);
    const dados = {
        titulo: formData.get('titulo').trim(),
        descricao: formData.get('descricao').trim(),
        prioridade: formData.get('prioridade')
    };
    
    if (!dados.titulo) {
        mostrarToast('Título é obrigatório', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/tarefas/criar/`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(dados)
        });
        
        const data = await response.json();
        
        if (data.sucesso) {
            mostrarToast('Tarefa criada com sucesso!', 'success');
            formNovaTarefa.reset();
            carregarTarefas();
        } else {
            mostrarToast(data.erro || 'Erro ao criar tarefa', 'error');
        }
    } catch (error) {
        console.error('Erro ao criar tarefa:', error);
        mostrarToast('Erro ao criar tarefa', 'error');
    }
}

async function atualizarTarefa(event) {
    event.preventDefault();
    
    if (!tarefaEditando) return;
    
    const formData = new FormData(formEditarTarefa);
    const dados = {
        titulo: formData.get('titulo').trim(),
        descricao: formData.get('descricao').trim(),
        status: formData.get('status'),
        prioridade: formData.get('prioridade')
    };
    
    if (!dados.titulo) {
        mostrarToast('Título é obrigatório', 'error');
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/tarefas/${tarefaEditando.id}/atualizar/`, {
            method: 'PUT',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(dados)
        });
        
        const data = await response.json();
        
        if (data.sucesso) {
            mostrarToast('Tarefa atualizada com sucesso!', 'success');
            fecharModal();
            carregarTarefas();
        } else {
            mostrarToast(data.erro || 'Erro ao atualizar tarefa', 'error');
        }
    } catch (error) {
        console.error('Erro ao atualizar tarefa:', error);
        mostrarToast('Erro ao atualizar tarefa', 'error');
    }
}

async function deletarTarefa(id) {
    if (!confirm('Tem certeza que deseja deletar esta tarefa?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/tarefas/${id}/deletar/`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (data.sucesso) {
            mostrarToast('Tarefa deletada com sucesso!', 'success');
            carregarTarefas();
        } else {
            mostrarToast(data.erro || 'Erro ao deletar tarefa', 'error');
        }
    } catch (error) {
        console.error('Erro ao deletar tarefa:', error);
        mostrarToast('Erro ao deletar tarefa', 'error');
    }
}

async function alterarStatus(id, novoStatus) {
    try {
        const response = await fetch(`${API_BASE_URL}/tarefas/${id}/status/`, {
            method: 'PATCH',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ status: novoStatus })
        });
        
        const data = await response.json();
        
        if (data.sucesso) {
            mostrarToast('Status alterado com sucesso!', 'success');
            carregarTarefas();
        } else {
            mostrarToast(data.erro || 'Erro ao alterar status', 'error');
        }
    } catch (error) {
        console.error('Erro ao alterar status:', error);
        mostrarToast('Erro ao alterar status', 'error');
    }
}

async function aplicarFiltros() {
    const status = filtroStatus.value;
    const prioridade = filtroPrioridade.value;
    
    if (!status && !prioridade) {
        renderizarTarefas(tarefas);
        return;
    }
    
    try {
        const params = new URLSearchParams();
        if (status) params.append('status', status);
        if (prioridade) params.append('prioridade', prioridade);
        
        const response = await fetch(`${API_BASE_URL}/tarefas/filtrar/?${params}`);
        const data = await response.json();
        
        if (data.sucesso) {
            renderizarTarefas(data.tarefas);
            atualizarContador(data.tarefas.length);
        } else {
            mostrarToast('Erro ao filtrar tarefas', 'error');
        }
    } catch (error) {
        console.error('Erro ao filtrar tarefas:', error);
        mostrarToast('Erro ao filtrar tarefas', 'error');
    }
}

function limparFiltros() {
    filtroStatus.value = '';
    filtroPrioridade.value = '';
    renderizarTarefas(tarefas);
    atualizarContador(tarefas.length);
}

// Funções de renderização
function renderizarTarefas(tarefasParaRenderizar) {
    if (tarefasParaRenderizar.length === 0) {
        listaTarefas.innerHTML = '';
        semTarefas.classList.remove('hidden');
        return;
    }
    
    semTarefas.classList.add('hidden');
    
    const tarefasHTML = tarefasParaRenderizar.map(tarefa => `
        <div class="task-item ${tarefa.status}" data-id="${tarefa.id}">
            <div class="task-header">
                <div>
                    <div class="task-title">${escapeHtml(tarefa.titulo)}</div>
                    ${tarefa.descricao ? `<div class="task-description">${escapeHtml(tarefa.descricao)}</div>` : ''}
                </div>
            </div>
            
            <div class="task-meta">
                <span class="task-status ${tarefa.status}">
                    <i class="fas fa-${getStatusIcon(tarefa.status)}"></i>
                    ${getStatusText(tarefa.status)}
                </span>
                
                <span class="task-priority ${tarefa.prioridade}">
                    <i class="fas fa-${getPrioridadeIcon(tarefa.prioridade)}"></i>
                    ${getPrioridadeText(tarefa.prioridade)}
                </span>
                
                <span class="task-date">
                    <i class="fas fa-calendar"></i>
                    Criada em ${tarefa.data_criacao}
                </span>
                
                ${tarefa.data_conclusao ? `
                    <span class="task-date">
                        <i class="fas fa-check-circle"></i>
                        Concluída em ${tarefa.data_conclusao}
                    </span>
                ` : ''}
            </div>
            
            <div class="task-actions">
                ${tarefa.status !== 'concluida' ? `
                    <button class="btn btn-success btn-sm" onclick="alterarStatus(${tarefa.id}, 'concluida')">
                        <i class="fas fa-check"></i> Concluir
                    </button>
                ` : ''}
                
                ${tarefa.status === 'pendente' ? `
                    <button class="btn btn-warning btn-sm" onclick="alterarStatus(${tarefa.id}, 'em_andamento')">
                        <i class="fas fa-play"></i> Iniciar
                    </button>
                ` : ''}
                
                ${tarefa.status === 'em_andamento' ? `
                    <button class="btn btn-secondary btn-sm" onclick="alterarStatus(${tarefa.id}, 'pendente')">
                        <i class="fas fa-pause"></i> Pausar
                    </button>
                ` : ''}
                
                <button class="btn btn-warning btn-sm" onclick="editarTarefa(${tarefa.id})">
                    <i class="fas fa-edit"></i> Editar
                </button>
                
                <button class="btn btn-danger btn-sm" onclick="deletarTarefa(${tarefa.id})">
                    <i class="fas fa-trash"></i> Deletar
                </button>
            </div>
        </div>
    `).join('');
    
    listaTarefas.innerHTML = tarefasHTML;
}

// Funções auxiliares
function editarTarefa(id) {
    const tarefa = tarefas.find(t => t.id === id);
    if (!tarefa) return;
    
    tarefaEditando = tarefa;
    
    document.getElementById('editId').value = tarefa.id;
    document.getElementById('editTitulo').value = tarefa.titulo;
    document.getElementById('editDescricao').value = tarefa.descricao || '';
    document.getElementById('editStatus').value = tarefa.status;
    document.getElementById('editPrioridade').value = tarefa.prioridade;
    
    abrirModal();
}

function abrirModal() {
    modalEditar.classList.remove('hidden');
    document.body.style.overflow = 'hidden';
}

function fecharModal() {
    modalEditar.classList.add('hidden');
    document.body.style.overflow = 'auto';
    tarefaEditando = null;
}

function mostrarLoading(mostrar) {
    if (mostrar) {
        loading.classList.remove('hidden');
        listaTarefas.classList.add('hidden');
    } else {
        loading.classList.add('hidden');
        listaTarefas.classList.remove('hidden');
    }
}

function atualizarContador(total) {
    totalTarefas.textContent = total;
}

function mostrarToast(mensagem, tipo = 'info') {
    toastMessage.textContent = mensagem;
    toast.className = `toast ${tipo}`;
    
    // Definir ícone baseado no tipo
    const icons = {
        success: 'fas fa-check-circle',
        error: 'fas fa-exclamation-circle',
        warning: 'fas fa-exclamation-triangle',
        info: 'fas fa-info-circle'
    };
    
    toastIcon.className = icons[tipo] || icons.info;
    
    // Mostrar toast
    toast.classList.remove('hidden');
    setTimeout(() => toast.classList.add('show'), 100);
    
    // Esconder após 3 segundos
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.classList.add('hidden'), 300);
    }, 3000);
}

// Funções de formatação
function getStatusIcon(status) {
    const icons = {
        pendente: 'clock',
        em_andamento: 'play',
        concluida: 'check-circle'
    };
    return icons[status] || 'question';
}

function getStatusText(status) {
    const texts = {
        pendente: 'Pendente',
        em_andamento: 'Em Andamento',
        concluida: 'Concluída'
    };
    return texts[status] || status;
}

function getPrioridadeIcon(prioridade) {
    const icons = {
        baixa: 'arrow-down',
        media: 'minus',
        alta: 'arrow-up'
    };
    return icons[prioridade] || 'question';
}

function getPrioridadeText(prioridade) {
    const texts = {
        baixa: 'Baixa',
        media: 'Média',
        alta: 'Alta'
    };
    return texts[prioridade] || prioridade;
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Fechar modal ao clicar fora
window.addEventListener('click', function(event) {
    if (event.target === modalEditar) {
        fecharModal();
    }
});

// Fechar modal com ESC
document.addEventListener('keydown', function(event) {
    if (event.key === 'Escape' && !modalEditar.classList.contains('hidden')) {
        fecharModal();
    }
}); 